from distutils.core import setup
import py2exe

setup(windows=["data_txt_to_data_csv.py"])