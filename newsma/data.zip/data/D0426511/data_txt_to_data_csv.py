import csv

with open('Data.txt', 'r') as in_file:
    stripped = (line.strip() for line in in_file)
    lines = (line.split("\t") for line in stripped if line)
  #  print(*lines, sep='\n')
    with open('Data.csv', 'w',newline='') as out_file:
        writer = csv.writer(out_file, quoting=csv.QUOTE_ALL)
        writer.writerow(('Phone_num', 'Name','Star','Line','Email'))        
        writer.writerows(lines)

in_file.close()