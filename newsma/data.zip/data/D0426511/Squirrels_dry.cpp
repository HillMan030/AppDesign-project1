#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>

using namespace std;

struct Member
{
	int phone;
	string name;
	string constellation;
	string line;
	string email;

	Member *prev;
	Member *next;

	Member(int phone, string name, string constellation, string line, string email) {
		this->setData(phone, name, constellation, line, email);
		this->next = NULL;
		this->prev = NULL;
	}

    int getPhone(){
        return (this-> phone);
    }

    string getName() {
        return (this-> name);
    }

    string getConstellation() {
        return (this-> constellation);
    }

    string getLine() {
        return (this-> line);

    }

    string getEmail() {
        return (this-> email);
    }

	void setData(int phone, string name, string constellation, string line, string email) {
		this->phone = phone;
		this->name = name;
		this->constellation = constellation;
		this->line = line;
		this->email = email;
	}

	void changeData(int phone, string name, string line, string email) {
        this->phone = phone;
		this->name = name;
		this->line = line;
		this->email = email;
	}

	void printData() {
		cout << "Name: " << this->name << endl;
		cout << "Phone: " << this->phone << endl;
		cout << "Constellation: " << this->constellation <<endl;
		cout << "Line: " << this->line << endl;
		cout << "E-mail: " << this->email << endl << endl;
	}
};

Member *HEAD = NULL;

void add(int phone, string name, string constellation, string line, string email) {

	Member *node = new Member(phone, name, constellation, line, email);
	if (HEAD != NULL) {
		Member *ptr = HEAD;
		while (ptr->next != NULL) {
			ptr = ptr->next;
		}
		ptr->next = node;
		node->prev = ptr;
	}
	else {
		HEAD = node;
	}

	return;
}

void openfile(){
        FILE *fp;
        int i=0, n=0, phone;
        char name1[50], constellation1[50], line1[50], email1[50];
        string name, constellation, line, email, save;

        fp = fopen("Data.txt","r");
            if (fp != NULL){
            while(!feof(fp)){
            fscanf(fp, "%d %s %s %s %s", &phone,&name1,&constellation1,&line1,&email1);
            name = string(name1);
            constellation = string(constellation1);
            line = string(line1);
            email = string(email1);
            add(phone, name, constellation, line, email);
            }
            fclose(fp);
}
}

void saveData(){
    Member *ptr = HEAD;
    Member *HEAD = NULL;
    FILE *fp;
    int phone, i=0;
    string save, name, con, line, email;
    fp = fopen("Data.txt","w");
    if (ptr ->next!= NULL) {
        while (ptr != NULL) {
            phone = ptr->getPhone();
            name = ptr->getName();
            con = ptr->getConstellation();
            line = ptr->getLine();
            email = ptr->getEmail();
            fprintf(fp, "\n%d\t%s\t%s\t%s\t%s", phone, name.c_str(), con.c_str(), line.c_str(), email.c_str());
            ptr = ptr->next;
        }
}
}

void delbyName(string name) {
	Member *ptr = HEAD;
	if (ptr != NULL) {
		while (ptr != NULL) {
			if (ptr->name == name) {
				break;
			}
			ptr = ptr->next;
		}
		if (ptr != NULL) {
			if (ptr == HEAD) {
				HEAD = ptr->next;
			}
			if (ptr->next != NULL) {
				ptr->next->prev = ptr->prev;
			}
			if (ptr->prev != NULL) {
				ptr->prev->next = ptr->next;
			}
			delete ptr;
			cout << "Info: Delete Successfully!" << endl;
		}
		else {
			cout << "Error: Not found!" << endl;
		}
	}
	else {
		cout << "Error: No data to delete!" << endl;
	}
	return;
}

void delbyPhone(int phone) {
	Member *ptr = HEAD;
	if (ptr != NULL) {
		while (ptr != NULL) {
			if (ptr->phone == phone) {
				break;
			}
			ptr = ptr->next;
		}
		if (ptr != NULL) {
			if (ptr == HEAD) {
				HEAD = ptr->next;
			}
			if (ptr->next != NULL) {
				ptr->next->prev = ptr->prev;
			}
			if (ptr->prev != NULL) {
				ptr->prev->next = ptr->next;
			}
			delete ptr;
			cout << "Info: Delete Successfully!" << endl;
		}
		else {
			cout << "Error: Not found!" << endl;
		}
	}
	else {
		cout << "Error: No data to delete!" << endl;
	}
	return;
}

void modifybyName(string name, int phone, string line, string email) {
	Member *ptr = HEAD;
	if (ptr != NULL) {
		while (ptr != NULL && ptr->name != name) {
			ptr = ptr->next;
		}
		if (ptr != NULL) {
			ptr->changeData(phone, name, line, email);
		}
		else {
			cout << "Error: Not found!" << endl;
		}
	}
	else {
		cout << "Error: No data to modify!" << endl;
	}
	return;
}

void modifybyPhone(int phone, string name, string line, string email) {
	Member *ptr = HEAD;
	if (ptr != NULL) {
		while (ptr != NULL && ptr->phone != phone) {
			ptr = ptr->next;
		}
		if (ptr != NULL) {
			ptr->changeData(phone, name, line, email);
		}
		else {
			cout << "Error: Not found!" << endl;
		}
	}
	else {
		cout << "Error: No data to modify!" << endl;
	}
	return;
}

void get(string name) {
	Member *ptr = HEAD;
	if (ptr != NULL) {
		while (ptr != NULL && ptr->name != name) {
			ptr = ptr->next;
		}
		if (ptr != NULL) {
			ptr->printData();
		}
		else {
			cout << "Error: Not found!" << endl;
		}
	}
	else {
		cout << "Error: No data to modify!" << endl;
	}
	return;
}

void printAll() {
	Member *ptr = HEAD;
	if (ptr != NULL) {
		while (ptr != NULL) {
			ptr->printData();
			ptr = ptr->next;
		}
	}
	else {
		cout << "Error: No data!" << endl;
	}
	return;
}

void search(int phone) {
	Member *ptr = HEAD;
	if (ptr != NULL) {
		bool found = false;
		while (ptr != NULL) {
			if (ptr->getPhone() == phone) {
				ptr->printData();
				found = true;
			}
			ptr = ptr->next;
		}
		if (!found) {
			cout << "Error: Not found!" << endl;
		}
	}
	else {
		cout << "Error: No data!" << endl;
	}
	return;
}

void printMenu() {
	cout << "Address Book" << endl;
	cout << "a) Add data" << endl;
	cout << "b) Delete Data by Name" << endl;
	cout << "c) Delete Data by Phone Number" <<endl;
	cout << "d) Modify Data by Name" << endl;
	cout << "e) Modify Data by Phone Number" << endl;
	cout << "f) Search Data by Name" << endl;
	cout << "g) Search Data by Phone Number" << endl;
	cout << "h) Print All Data" << endl;
	cout << "i) Exit" << endl;
	cout << "Your choice: ";
	return;
}

int main() {
	char ch;
	int phone;
	string name, constellation, line, email;

	openfile();
	do {
		printMenu();
		cin >> ch;
		switch (ch) {
		case 'A':
		case 'a':
			cout << "Enter Phone Number: ";
			cin >> phone;
			cout << "Enter Name: ";
			cin >> name;
			cout << "Enter Constellation: ";
			cin >> constellation;
			cout << "Enter Line: ";
			cin >> line;
			cout <<"Enter E-mail: ";
			cin >> email;
			add(phone, name, constellation, line, email);
			break;
		case 'B':
		case 'b':
			cout << "Enter name: ";
			cin >> name;
			delbyName(name);
			break;
        case 'C':
		case 'c':
			cout << "Enter Phone Number: ";
			cin >> phone;
			delbyPhone(phone);
			break;
		case 'D':
		case 'd':
			cout << "Enter name: ";
			cin >> name;
			cout << "Enter new Phone Number: ";
			cin >> phone;
			cout << "Enter new line: ";
			cin >> line;
			cout << "Enter new E-mail: ";
			cin >> email;
			modifybyName(name, phone, line, email);
			break;
        case 'E':
		case 'e':
			cout << "Enter Phone Number: ";
			cin >> phone;
			cout << "Enter new Name: ";
			cin >> name;
			cout << "Enter new line: ";
			cin >> line;
			cout << "Enter new E-mail: ";
			cin >> email;
			modifybyPhone(phone, name, line, email);
			break;

		case 'F':
		case 'f':
			cout << "Enter Name: ";
			cin >> name;
			get(name);
			break;
		case 'G':
		case 'g':
			cout << "Enter Phone Number: ";
			cin >> phone;
			search(phone);
			break;
		case 'H':
		case 'h':
			printAll();
			break;
		case 'I':
		case 'i':
		    saveData();
			cout << "Bye!" << endl;
			break;
		default:
			cout << "Error: Wrong input!" << endl;
		}
		cout << endl << endl;
	} while (ch != 'I' && ch != 'i');
	return 0;
}
