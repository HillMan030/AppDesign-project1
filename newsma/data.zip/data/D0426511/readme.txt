Squirrels_dry.cpp is the major program.Which included addressbook features.We wrote it in C and C++.
Data.txt is the input and output file include all the date of addressbook.
data_txt_to_data_csv.py is the program translate data.txt to data.csv.We wrote it in python.But it needs Python3.6 environment, so we make a exe for it.

How to convert to csv if you dont have python3.6 environment.
1.copy data.txt to  D0426511\data_txt_to_data_csv\dist\data_txt_to_data_csv  file
2.run data_txt_to_data_csv.exe