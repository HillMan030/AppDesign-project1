import pandas as pd
import re
import jieba
import string

sentiment_df = pd.read_csv('SentimentDict.csv',encoding='utf-8')

positives_set = set(sentiment_df.positive)
negatives_set = set(sentiment_df.negative)
not_set = set(sentiment_df['not'])

degree_dict = {}
for word in sentiment_df['degree-1']:
    degree_dict[word] = 1.8
for word in sentiment_df['degree-2']:
    degree_dict[word] = 1.6
for word in sentiment_df['degree-3']:
    degree_dict[word] = 1.4
for word in sentiment_df['degree-4']:
    degree_dict[word] = 1.2
for word in sentiment_df['degree-5']:
    degree_dict[word] = 1.1
for word in sentiment_df['degree-6']:
    degree_dict[word] = 1.5


def hasOpposite(wordlist):
    opp = False

    for word in wordlist:
        if word in not_set:
            opp = True
    
    return opp

def getDegree(wordlist):
    degree = 1.0
    for word in wordlist:
        if word in degree_dict:
            degree = degree_dict[word]
    
    return degree


def analyze (text):
    token = list(jieba.cut(text))
    print(token)
    sum  = 0 
    for word in token:
        if word.lower() in positives_set:
            sum += 1
        elif word.lower() in negatives_set:
            sum -= 1
    
    if hasOpposite(token):
        sum = -sum
    
    sum = sum*getDegree(token)
    
    return sum
    
def sentiment_analysis(text):
    sentiment = 0
    score =  analyze(text)
    print('情感分數',score)
    if score > 0:
        sentiment = 1
    elif score < 0.0:
        sentiment = 0
    return sentiment
    
def delwords(wordlist):
    delims = [
                     "，", "。", "；", "：", "！",
                     "?", "？", ";", ":", "!",
                     ",", ".", "\"", "'", "“",
                     "‘", "’", "(", ")", "”",
                     "（", "）", "%", "％", "@",
                     "~", "`", "～", "｀", "#",
                     "、", "/", "\\", "<", ">",
                     "《", "》", "／", "｛", "｝",
                     "{", "}", "[", "]", "［",
                     "］", "|", "｜", "\r",'@','◎','【',  '】',
                     " ", "\t", "　", '+','=','*','^','·'
                 ] \
                 + list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") \
                 + list("abcdefghijklmnopqrstuvwxyz") \
                 + list("0123456789") \
                 + list(string.punctuation)
    
    escaped = re.escape(''.join(delims))
    exclusions = '['+escaped+']'
    text = re.sub(exclusions, ' ', wordlist)
    text = re.sub(' +', " ", text)
    words = [word for word in text if word != '']
    words = [word for word in words if word != ' ']
    words = [w.replace(" ", "") for w in words]
    return text




with open('output1.txt') as f:
    output = f.read()
    
text=delwords(output)
for i in text.split('\n'):
    print('正負向',sentiment_analysis(i))
    
    
x = input('x')
str1=str(x)+'.txt'

with open(str1) as f:
    output = f.read()
    
text=delwords(output)
for i in text.split('\n'):
    print('正負向',sentiment_analysis(i))