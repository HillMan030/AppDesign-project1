'''import nltk
from urllib.request import urlopen
from nltk import ngrams
from nltk import Text
from nltk import FreqDist'''

from bs4 import BeautifulSoup
import string
import requests




session = requests.Session()
headers = {"User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit 537.36 (KHTML, like Gecko) Chrome","Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"}


    
def findinptt(ptt,str1):
    req = session.get(ptt, headers=headers)
    temp = BeautifulSoup(req.text, "lxml")
    contents = [tag.text for tag in temp.find_all('div',  {"class":str1})]
    href1 = temp.find_all('div',{"class":"title"})
    href2=[]

#    j=0
    try:
        for i in href1:
            href2.append(i.find('a').attrs['href'])
        #    j+=1
            #if j>=len(href1)-2 :
              #  break
    except:
        print('none1')
    return contents,href2


url="https://www.ptt.cc/bbs/hotboards.html"
req = session.get(url, headers=headers)
bsObj = BeautifulSoup(req.text, "lxml")
contents = bsObj.find("div", {"class":"b-list-container action-bar-margin bbs-screen"})





board_classes = [tag.text for tag in contents.find_all('div',  {"class":"board-class"})]
board_titles = [tag.text for tag in contents.find_all('div',  {"class":"board-title"})]
i=0
str2=[]
for board_class,board_title in zip(board_classes,board_titles):
   i+=1
   str1=str(i)+" "+board_class+"    "+board_title
   str2.append(str1)
str2='\n'.join(str2)
str2.encode('utf-8')

try:
    with open("Output.txt", "w") as text_file:
        text_file.write("%s" % str2)
except:
    print('none')
print(str2)


href = bsObj.find_all('a',{'class':'board'})
type(href)
ptt='https://www.ptt.cc'
#x=int(input('which one do u want to find:'))

x=0
#if(x>=1 and x<=128):
for x in range(0,128,+1):
    print("你要找"+board_classes[x]+"板?")
    ptt+=href[x].attrs['href']
    str1="title"
    pttarrays,ptthrefs=findinptt(ptt,str1)
    with open(str(x)+".txt", "w") as text_file:
        for pttarray,ptthref in zip(pttarrays,ptthrefs):
           # print(pttarray)
           # print('https://www.ptt.cc'+ptthref)
            str123='https://www.ptt.cc'+ptthref
           # with open(x+".txt", "w") as text_file:
            try:
                
                text_file.write("%s" % pttarray)
                text_file.write("%s" % str123)
            except:
                print("none2")
    ptt='https://www.ptt.cc'
  


